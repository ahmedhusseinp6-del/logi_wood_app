package com.logiwood.live

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF0B0B18)
private val Purple = Color(0xFF7C3AED)
private val Pink = Color(0xFFFF3D9A)
private val Gold = Color(0xFFFFC857)

data class Room(val title: String, val host: String, val people: Int, val tag: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LogiWoodApp() }
    }
}

@Composable
fun LogiWoodApp() {
    var tab by remember { mutableStateOf(0) }
    var selectedRoom by remember { mutableStateOf<Room?>(null) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Navy,
            surface = Color(0xFF17172A),
            primary = Purple,
            secondary = Pink
        )
    ) {
        if (selectedRoom != null) {
            VoiceRoom(selectedRoom!!) { selectedRoom = null }
        } else {
            Scaffold(
                containerColor = Navy,
                bottomBar = {
                    NavigationBar(containerColor = Color(0xFF121222)) {
                        val items = listOf(
                            Icons.Default.Home to "الرئيسية",
                            Icons.Default.Mic to "الغرف",
                            Icons.Default.EmojiEvents to "الترتيب",
                            Icons.Default.Person to "حسابي"
                        )
                        items.forEachIndexed { i, item ->
                            NavigationBarItem(
                                selected = tab == i,
                                onClick = { tab = i },
                                icon = { Icon(item.first, null) },
                                label = { Text(item.second) }
                            )
                        }
                    }
                }
            ) { pad ->
                when (tab) {
                    0 -> Home(Modifier.padding(pad)) { selectedRoom = it }
                    1 -> Rooms(Modifier.padding(pad)) { selectedRoom = it }
                    2 -> Leaderboard(Modifier.padding(pad))
                    3 -> Profile(Modifier.padding(pad))
                }
            }
        }
    }
}

@Composable
fun Header() {
    Row(
        Modifier.fillMaxWidth().padding(18.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text("LOGI WOOD", color = Gold, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
            Text("Live • Voice • Games", color = Color.LightGray, fontSize = 12.sp)
        }
        Surface(shape = RoundedCornerShape(20.dp), color = Color(0xFF24243A)) {
            Row(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("🪙", fontSize = 16.sp)
                Spacer(Modifier.width(6.dp))
                Text("12,500", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun Home(modifier: Modifier, open: (Room) -> Unit) {
    val rooms = listOf(
        Room("سهرة LOGI WOOD", "Lina", 128, "موسيقى"),
        Room("Arab Lounge", "Ahmed", 86, "دردشة"),
        Room("PK Arena", "Mido", 64, "PK"),
        Room("Game Night", "Nour", 42, "ألعاب")
    )
    LazyColumn(modifier.fillMaxSize()) {
        item { Header() }
        item {
            Text("الغرف النشطة 🔥", Modifier.padding(horizontal = 18.dp, vertical = 8.dp),
                fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        items(rooms) { room -> RoomCard(room) { open(room) } }
    }
}

@Composable
fun Rooms(modifier: Modifier, open: (Room) -> Unit) {
    val rooms = listOf(
        Room("VIP Lounge", "Sara", 220, "VIP"),
        Room("تعال نتكلم", "Omar", 73, "دردشة"),
        Room("PK Challenge", "Kareem", 98, "PK"),
        Room("Ludo Masters", "Mona", 55, "Ludo")
    )
    LazyColumn(modifier.fillMaxSize()) {
        item { Header() }
        item { Text("كل الغرف", Modifier.padding(18.dp), fontSize = 22.sp, fontWeight = FontWeight.Bold) }
        items(rooms) { room -> RoomCard(room) { open(room) } }
    }
}

@Composable
fun RoomCard(room: Room, open: () -> Unit) {
    Card(
        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 7.dp).clickable { open() },
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF19192C))
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(62.dp).clip(CircleShape)
                    .background(Brush.linearGradient(listOf(Pink, Purple))),
                contentAlignment = Alignment.Center
            ) { Text("🎙️", fontSize = 27.sp) }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(room.title, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text("Host: ${room.host}", color = Color.LightGray, fontSize = 12.sp)
                Text("${room.people} داخل الغرفة", color = Color(0xFFBDB8FF), fontSize = 12.sp)
            }
            AssistChip(onClick = { open() }, label = { Text(room.tag) })
        }
    }
}

@Composable
fun VoiceRoom(room: Room, back: () -> Unit) {
    var muted by remember { mutableStateOf(false) }
    var gifts by remember { mutableStateOf(0) }

    Column(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xFF17102A), Navy))
        )
    ) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = back) { Icon(Icons.Default.ArrowBack, "رجوع") }
            Column(Modifier.weight(1f)) {
                Text(room.title, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text("👥 ${room.people}  •  ${room.tag}", color = Color.LightGray, fontSize = 12.sp)
            }
            Text("🪙 12,500", color = Gold, fontWeight = FontWeight.Bold)
        }

        Box(Modifier.fillMaxWidth().height(150.dp).padding(16.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(Brush.linearGradient(listOf(Purple, Pink))),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("🎙️", fontSize = 54.sp)
                Text("مباشر الآن", color = Color.White, fontWeight = FontWeight.Bold)
            }
        }

        Text("المتحدثون", Modifier.padding(18.dp), fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp),
            horizontalArrangement = Arrangement.spacedBy(18.dp)) {
            listOf("Lina", "Omar", "Sara", "Mido").forEach {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(Modifier.size(54.dp).clip(CircleShape).background(Purple),
                        contentAlignment = Alignment.Center) { Text("👤", fontSize = 24.sp) }
                    Text(it, fontSize = 11.sp)
                }
            }
        }

        Spacer(Modifier.weight(1f))
        Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            FilledTonalButton(onClick = { muted = !muted }) {
                Text(if (muted) "🔇 مكتوم" else "🎙️ المايك")
            }
            Button(onClick = { gifts++ }) { Text("🎁 هدية $gifts") }
            FilledTonalButton(onClick = { }) { Text("⚔️ PK") }
        }
    }
}

@Composable
fun Leaderboard(modifier: Modifier) {
    val users = listOf("Lina" to "125,400", "Mido" to "98,200", "Sara" to "84,600", "Omar" to "72,100")
    Column(modifier.fillMaxSize().padding(18.dp)) {
        Header()
        Text("🏆 الترتيب", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(14.dp))
        users.forEachIndexed { i, u ->
            Card(Modifier.fillMaxWidth().padding(vertical = 5.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF19192C))) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("#${i+1}", Modifier.width(45.dp), color = Gold, fontWeight = FontWeight.Bold)
                    Text(u.first, Modifier.weight(1f), fontWeight = FontWeight.Bold)
                    Text("🪙 ${u.second}")
                }
            }
        }
    }
}

@Composable
fun Profile(modifier: Modifier) {
    Column(modifier.fillMaxSize().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Header()
        Spacer(Modifier.height(25.dp))
        Box(Modifier.size(100.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Pink, Purple))),
            contentAlignment = Alignment.Center) { Text("👤", fontSize = 45.sp) }
        Spacer(Modifier.height(12.dp))
        Text("Ahmed", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("ID: 100001", color = Color.LightGray)
        Spacer(Modifier.height(22.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            Stat("متابعين", "1.2K")
            Stat("متابعة", "320")
            Stat("هدايا", "8.4K")
        }
        Spacer(Modifier.height(30.dp))
        OutlinedButton(onClick = {}) { Text("تعديل الملف الشخصي") }
    }
}

@Composable
fun Stat(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Text(label, color = Color.LightGray, fontSize = 12.sp)
    }
}
