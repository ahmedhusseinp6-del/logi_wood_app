# LOGI WOOD — Android MVP

نسخة أولية فعلية بواجهة Android Jetpack Compose.

## الموجود حالياً
- Home / الغرف النشطة
- Voice Room UI
- Mic mute toggle
- Gifts counter
- PK button
- Leaderboard
- Profile
- Coins display
- Arabic RTL-friendly UI
- LOGI WOOD branding

## المرحلة التالية للإنتاج
1. Backend + database
2. Real-time voice (مثل Agora/LiveKit)
3. Authentication + OTP
4. Real coin wallet + payment gateway
5. Gifts animation
6. Real PK
7. Ludo/game rooms
8. Admin dashboard
9. Moderation/report/block
10. Push notifications

افتح المشروع في Android Studio ثم Sync وRun.
